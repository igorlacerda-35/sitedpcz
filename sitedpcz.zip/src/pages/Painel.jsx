export default function Painel() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Painel do Cliente</h1>
      <p>Aqui você poderá gerenciar seu projeto, como os números autorizados.</p>
    </div>
  );
}
